package ass.sivakfil.cvi5.hw5;

import org.joda.time.DateTime;

public class Record {

	protected DateTime time;
	protected int telephone;
	
}

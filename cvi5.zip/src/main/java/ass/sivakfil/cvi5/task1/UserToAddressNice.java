package ass.sivakfil.cvi5.task1;

import java.util.Optional;

public class UserToAddressNice {

	public static Optional<String> userToStreet(User user) {
		return null; 
		
		// HINT:
		/* Optional.ofNullable(user).m... */
	}
	
}

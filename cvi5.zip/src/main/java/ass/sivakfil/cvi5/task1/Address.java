package ass.sivakfil.cvi5.task1;

public class Address {
	protected String street = null;

	public Address(String street) {
		super();
		this.street = street;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}
	
}

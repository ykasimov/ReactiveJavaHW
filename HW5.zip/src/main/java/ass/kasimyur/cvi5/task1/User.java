package ass.kasimyur.cvi5.task1;

public class User {
	
	protected Address address;

	public User(Address address) {
		super();
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	
	
}
